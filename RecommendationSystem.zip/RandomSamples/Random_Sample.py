import pandas as pd
from random import sample

if __name__ == '__main__':
    ratings = pd.read_csv('../data-1m/ratings_original.csv')
    movies = pd.read_csv('../data-1m/movies_original.csv')

    mean_no_of_ratings = ratings.groupby('userId')['movieId'].count().mean()

    users = ratings.groupby('userId')['movieId'].count() > mean_no_of_ratings * 0.5
    users = users[users == True]
    users = list(users.index)

    random_users = sample(users, 30)
    df_sample = pd.DataFrame([], columns=random_users)
    for user in random_users:
        rated_movies = ratings[ratings['userId'] == user]['movieId'].tolist()
        random_movies = sample(rated_movies, 30)
        df_sample[user] = pd.Series(random_movies)

    df_sample.to_csv('Random_sample5.csv')
