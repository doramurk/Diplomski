import math

import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
from sklearn.metrics.pairwise import cosine_similarity

ratings = pd.read_csv('data-1m/ratings_original.csv')
movies = pd.read_csv('data-1m/movies_original.csv')


def get_utility_matrix(n_users, n_movies, df_ratings):
    row = []
    col = []
    rating = []
    for r in df_ratings.itertuples():
        row.append(r[1] - 1)
        col.append(r[2])
        rating.append(r[3])
    users_data = coo_matrix((rating, (row, col)), shape=(n_users, n_movies))

    df_utility = pd.DataFrame([])
    for userId in df_ratings['userId'].unique():
        df_user = pd.Series(data=users_data.toarray()[userId - 1])
        df_utility.insert(loc=int(userId - 1), value=df_user, column=userId - 1)
    df_utility = df_utility.T
    return df_utility


def normalize_utility_matrix(df_utility):
    df_utility[df_utility == 0.0] = np.nan
    for i in df_utility.index:
        srednja = np.nanmean(df_utility.loc[i])
        df_utility.loc[i] = df_utility.loc[i] - srednja
    df_utility = df_utility.fillna(0)
    return df_utility


def calculate_user_similarity(df_utility, userId):
    user_similarity = [
        cosine_similarity(X=np.array(df_utility.iloc[int(userId) - 1], ndmin=2), Y=np.array(df_utility, ndmin=2))]
    df_user_similarity = pd.DataFrame(data=user_similarity[0][0], columns=['similarity'])
    df_user_similarity = df_user_similarity.sort_values(['similarity'], ascending=False).query(
        'similarity < 0.99999 and similarity > 0.001').head(50)
    df_user_similarity.insert(1, 'userId', df_user_similarity.index + 1)
    return df_user_similarity


def prep_data_for_CF(userId, df_utility):
    global movies, ratings

    df_user_similarity = calculate_user_similarity(df_utility, userId)

    df_user_similarity_ratings = df_user_similarity.merge(df_ratings[["userId", "index", "rating"]], how='left',
                                                          left_on='userId', right_on='userId')
    df_user_similarity_ratings_movie = df_user_similarity_ratings.merge(df_movies, on='index')
    return df_user_similarity_ratings_movie


def predict_CF(movieId, userId, df_user_similarity_ratings_movie_original):
    mean_user = ratings[ratings['userId'] == int(userId)]['rating'].mean()
    mean_similar_users = df_user_similarity_ratings_movie_original['rating'].mean()
    ratio = mean_user - mean_similar_users
    df_user_similarity_ratings_movie = df_user_similarity_ratings_movie_original[
        df_user_similarity_ratings_movie_original['movieId'] == movieId]
    return (min((np.dot(df_user_similarity_ratings_movie['rating'],
                  df_user_similarity_ratings_movie['similarity'].T) /
                  df_user_similarity_ratings_movie['similarity'].sum()) + ratio, 5.0),
            len(df_user_similarity_ratings_movie))


if __name__ == '__main__':
    #global movies, ratings
    df_random_sample = pd.read_csv('RandomSamples/Random_sample5.csv')
    df_predictions = pd.DataFrame([], columns=list(df_random_sample.columns)[1:], index=df_random_sample.index)

    error = []

    users = list(df_random_sample.columns)[1:]

    df_movies = movies.reset_index()

    df_ratings = ratings.merge(df_movies, on='movieId')[["userId", "index", "rating", "movieId"]].sort_values(
        ["userId", "index"])

    n_users = df_ratings.userId.unique().shape[0]
    n_movies = df_movies.movieId.unique().shape[0]

    df_utility = get_utility_matrix(n_users, n_movies, df_ratings)
    df_utility = normalize_utility_matrix(df_utility)

    for userId in users:
        df_user_similarity_ratings_movie_original = prep_data_for_CF(userId, df_utility)
        predictions = []
        for movieId in df_random_sample[userId]:
            (predicted, no_of_rated) = predict_CF(movieId, userId, df_user_similarity_ratings_movie_original)
            predictions.append(predicted)
            actual_value = ratings[(ratings['userId'] == int(userId)) & (ratings['movieId'] == movieId)]['rating']


            error.append(math.fabs(predicted - actual_value))

        df_predictions[userId] = predictions
    df_predictions.to_csv('predictions/CF_predictions5.csv')
    rmse = math.sqrt(np.nansum(np.square(np.array(error))) / len(error))
    mae = np.nansum(np.array(error)) / len(error)
    print("rmse: " + str(rmse))
    print("mae: " + str(mae))
