import pandas as pd
import numpy as np
import math
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

df_movies = pd.read_csv('data-1m/movies_original.csv')
df_ratings_original = pd.read_csv('data-1m/ratings_original.csv')


def _concatenate_genres_of_movie(genres):
    genre = str(genres)
    list_of_strings = genre.split('|')
    tags_as_str = " ".join(list_of_strings)
    return tags_as_str


def predict(MOVIE_ID, USER_ID):
    global df_movies, df_ratings_original

    df_ratings = df_ratings_original[(df_ratings_original['userId'] == int(USER_ID)) & ~(df_ratings_original['movieId'] == MOVIE_ID)]

    idx = df_movies.index[df_movies['movieId'] == MOVIE_ID]
    df_most_similar = df_tfidf_m2m.iloc[idx].T.drop(idx)
    df_most_similar = df_most_similar[df_most_similar[df_most_similar.columns[0]] > 0.6]
    df_most_similar = df_most_similar.sort_values(by=df_most_similar.columns[0], ascending=False)

    df_most_similar_rated = df_most_similar.merge(df_movies, how='left', left_index=True, right_index=True)
    df_most_similar_rated = df_most_similar_rated.merge(df_ratings, how='right', left_on='movieId', right_on='movieId')
    df_most_similar_rated = df_most_similar_rated[~df_most_similar_rated['title'].isna()].sort_values(
        by=df_most_similar_rated.columns[0], ascending=False)
    df_most_similar_rated['rating_normalized'] = df_most_similar_rated['rating'] - df_most_similar_rated[
        'rating'].mean()

    rate = np.dot(df_most_similar_rated[df_most_similar_rated.columns[0]], df_most_similar_rated['rating'].T) / \
           df_most_similar_rated[df_most_similar_rated.columns[0]].sum()

    return rate


if __name__ == '__main__':
    df_random_sample = pd.read_csv('RandomSamples/Random_sample5.csv')
    df_predictions = pd.DataFrame([], columns=list(df_random_sample.columns)[1:], index=df_random_sample.index)

    df_movies['genres'] = df_movies['genres'].agg(_concatenate_genres_of_movie)
    tf_idf = TfidfVectorizer()
    df_movies_tf_idf_described = tf_idf.fit_transform(df_movies['genres'])
    df_tfidf_m2m = pd.DataFrame(cosine_similarity(df_movies_tf_idf_described))

    error = []

    users = list(df_random_sample.columns)[1:]
    for userId in users:
        predictions = []
        for movieId in df_random_sample[userId]:
            predicted = predict(movieId, userId)
            predictions.append(predicted)
            actual_value = df_ratings_original[(df_ratings_original['userId'] == int(userId)) &
                                               (df_ratings_original['movieId'] == movieId)]['rating']

            error.append(math.fabs(predicted - actual_value))

        df_predictions[userId] = predictions
    df_predictions.to_csv('predictions/CB_predictions5.csv')
    rmse = math.sqrt(np.nansum(np.square(np.array(error))) / len(error))
    mae = np.nansum(np.array(error)) / len(error)
    print("rmse: " + str(rmse))
    print("mae: " + str(mae))
