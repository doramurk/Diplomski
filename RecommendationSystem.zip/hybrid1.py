import math

import pandas as pd
import numpy as np

if __name__ == '__main__':
    USER_ID = 1
    df_CF_predictions = pd.read_csv('predictions/CF_predictions1.csv')
    df_CB_predictions = pd.read_csv('predictions/CB_predictions1.csv')

    print(df_CF_predictions.describe())
    print(df_CB_predictions.describe())

    df_predictions = (1.5 * df_CF_predictions + 1.0 * df_CB_predictions) / 2.5

    df_random_sample = pd.read_csv('RandomSamples/Random_sample1.csv')
    ratings = pd.read_csv('data-1m/ratings_original.csv')

    error = []

    users = list(df_random_sample.columns)[1:]
    for userId in users:
        for i, movieId in enumerate(df_random_sample[userId]):
            predicted = df_predictions.loc[i, userId]
            actual_value = ratings[
                (ratings['userId'] == int(userId)) & (ratings['movieId'] == movieId)]['rating']

            error.append(math.fabs(predicted - actual_value))

    rmse = math.sqrt(np.nansum(np.square(np.array(error))) / len(error))
    mae = np.nansum(np.array(error)) / len(error)
    print("rmse: " + str(rmse))
    print("mae: " + str(mae))
